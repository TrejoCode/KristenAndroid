package mx.edu.upqroo.kristenandroid.adapters;

public class TestAdapter {
}
