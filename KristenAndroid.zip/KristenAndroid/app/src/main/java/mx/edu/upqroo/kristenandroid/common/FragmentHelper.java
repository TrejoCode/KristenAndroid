package mx.edu.upqroo.kristenandroid.common;

public enum FragmentHelper {
    NEWS, USER, SCHEDULE, GRADES, KARDEX, GROUPS
}
